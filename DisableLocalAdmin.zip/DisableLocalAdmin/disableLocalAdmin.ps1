Configuration disableLocalAdmin
{
    Param (
        [Parameter(Mandatory)]
        [string] $localadminname
    )
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'

    Node localhost
    {
        User $localadminname
        {
            UserName = $localadminname
            Disabled = $true
        }
    }
}